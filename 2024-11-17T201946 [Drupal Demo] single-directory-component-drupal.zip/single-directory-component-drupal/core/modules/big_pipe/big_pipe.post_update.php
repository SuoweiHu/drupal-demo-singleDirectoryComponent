<?php

/**
 * @file
 * Post update functions for Big Pipe.
 */

/**
 * Clear the render cache.
 */
function big_pipe_post_update_html5_placeholders() {
  // Empty post_update hook.
}
